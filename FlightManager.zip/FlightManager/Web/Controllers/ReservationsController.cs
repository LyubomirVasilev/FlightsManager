﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Data;
using Data.Entity;
using Web.Models.Shared;
using Web.Models.Reservations;
using System.Net.Mail;
using System.Net;

namespace Web.Controllers
{
    public class ReservationsController : Controller
    {
        private const int PageSize = 10;
        private readonly FlightsManagerDb _context;

        public ReservationsController(FlightsManagerDb context)
        {
            _context = context;
        }

        // GET: Reservations
        public async Task<IActionResult> Index(ReservationsIndexViewModel model)
        {
            model.Pager ??= new PagerViewModel();
            model.Pager.CurrentPage = model.Pager.CurrentPage <= 0 ? 1 : model.Pager.CurrentPage;

            List<ReservationsViewModel> items = await _context.Reservations.Skip((model.Pager.CurrentPage - 1) * PageSize).Take(PageSize).Select(c => new ReservationsViewModel()
            {
                FirstName = c.FirstName,
                SecondName = c.SecondName,
                LastName = c.LastName,
                EGN = c.EGN,
                PhoneNumber = c.PhoneNumber,
                Email = c.Email,
                Nationality = c.Nationality,
                FlightId = c.FlightId,
                ClassType = c.ClassType

            }).ToListAsync();

            model.Items = items;
            model.Pager.PagesCount = (int)Math.Ceiling(await _context.Reservations.CountAsync() / (double)PageSize);

            return View(model);
        }

        //GET: Reservations/Create
        public IActionResult Create(string flightId)
        {
            ReservationsCreateViewModel model = new ReservationsCreateViewModel();
            
            model.FlightId = flightId;
            
            return View(model);
        }

        // POST: Reservations/Create        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ReservationsCreateViewModel createModel)
        {
            if (ModelState.IsValid)
            {
                Reservation reservation = new Reservation
                {
                    Id = Guid.NewGuid().ToString(),
                    FirstName = createModel.FirstName,
                    SecondName = createModel.SecondName,
                    LastName = createModel.LastName,
                    EGN = createModel.EGN,
                    PhoneNumber = createModel.PhoneNumber,
                    Nationality = createModel.Nationality,
                    Email = createModel.Email,
                    FlightId = createModel.FlightId,
                    ClassType = createModel.ClassType
                };

                Flight flight = await _context.Flights.FindAsync(reservation.FlightId);
                if (flight == null)
                {
                    return View("ABC");
                }

                //Flight seats decrement:

                switch (reservation.ClassType)
                {
                    case "Economy":
                        if (flight.FreeSeatsEconomy > 0)
                        {
                            flight.FreeSeatsEconomy -= 1;
                        }
                        else
                        {
                            return NotFound();
                        }
                        break;
                    case "Business":
                        if (flight.FreeSeatsBusiness > 0)
                        {
                            flight.FreeSeatsBusiness -= 1;
                        }
                        else
                        {
                            return NotFound();
                        }
                        break;
                    default: return NotFound();
                }

                try
                {
                    _context.Update(flight);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FlightExists(flight.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                _context.Add(reservation);
                SendConfirmationEmail(reservation);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            return View(createModel);
        }

        private bool FlightExists(string id)
        {
            return _context.Flights.Any(e => e.Id == id);
        }

        private void SendConfirmationEmail(Reservation reservation)
        {
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
            client.UseDefaultCredentials = false;
            client.Credentials = new NetworkCredential("modul13Test", "Izpit2020.");
            client.EnableSsl = true;

            MailMessage mailMessage = new MailMessage();
            mailMessage.From = new MailAddress("modul13Test@gmail.com");
            mailMessage.To.Add(reservation.Email);
            mailMessage.Body = "Hello, this is an email for your reservation." + Environment.NewLine +
                                $"Your flight: {reservation.FlightId}" + Environment.NewLine +
                                $"For passenger: {reservation.FirstName} {reservation.SecondName} {reservation.LastName}" + Environment.NewLine +
                                $"Class type: {reservation.ClassType}";
            mailMessage.Subject = "Reservation confirmed";
            client.Send(mailMessage);
        }
    }
}
