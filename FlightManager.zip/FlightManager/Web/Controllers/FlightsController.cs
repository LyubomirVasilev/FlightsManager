﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Data;
using Data.Entity;
using Web.Models.Flights;
using Web.Models.Shared;
using Web.Models.Reservations;
using Microsoft.AspNetCore.Identity;

namespace Web.Controllers
{
    public class FlightsController : Controller
    {
        private const int PageSize = 10;
        private readonly FlightsManagerDb _context;

        public FlightsController(FlightsManagerDb context)
        {
            _context = context;
        }

        // GET: Flights
        public async Task<IActionResult> Index(FlightsIndexViewModel model)
        {
            //this._context.Roles.Add(new IdentityRole()
            //{
            //    Name = "Admin",
            //    NormalizedName = "Admin"
            //});
            //this._context.Roles.Add(new IdentityRole()
            //{
            //    Name = "Employee",
            //    NormalizedName = "Employee"
            //});
            //await _context.SaveChangesAsync();

            model.Pager ??= new PagerViewModel();
            model.Pager.CurrentPage = model.Pager.CurrentPage <= 0 ? 1 : model.Pager.CurrentPage;

            List<FlightsViewModel> items = await _context.Flights.Skip((model.Pager.CurrentPage - 1) * PageSize).Take(PageSize).Select(c => new FlightsViewModel()
            {
                Id = c.Id,
                From = c.From,
                To = c.To,
                Departure = c.Departure,
                Arrival = c.Arrival,
                Plane = c.Plane,
                PlaneCode = c.PlaneCode,
                PilotName = c.PilotName,
                FreeSeatsEconomy = c.FreeSeatsEconomy,
                FreeSeatsBusiness = c.FreeSeatsBusiness

            }).ToListAsync();

            model.Items = items;
            model.Pager.PagesCount = (int)Math.Ceiling(await _context.Flights.CountAsync() / (double)PageSize);

            return View(model);
        }


        // GET: Flights/Create
        public IActionResult Create()
        {
            FlightsCreateViewModel model = new FlightsCreateViewModel();

            return View(model);
        }

        // POST: Flights/Create        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(FlightsCreateViewModel createModel)
        {
            if (ModelState.IsValid)
            {
                Flight flight = new Flight
                {
                    Id = Guid.NewGuid().ToString(),
                    From = createModel.From,
                    To = createModel.To,
                    Departure = createModel.Departure,
                    Arrival = createModel.Arrival,
                    Plane = createModel.Plane,
                    PlaneCode = createModel.PlaneCode,
                    PilotName = createModel.PilotName,
                    FreeSeatsEconomy = createModel.FreeSeatsEconomy,
                    FreeSeatsBusiness = createModel.FreeSeatsBusiness
                };

                _context.Add(flight);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            return View(createModel);
        }


        // GET: Flights/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            
            if (id == null)
            {
                return NotFound();
            }

            Flight flight = await _context.Flights.FindAsync(id);
            if (flight == null)
            {
                return NotFound();
            }

            FlightsEditViewModel model = new FlightsEditViewModel
            {
                Id = flight.Id,
                From = flight.From,
                To = flight.To,
                Departure = flight.Departure,
                Arrival = flight.Arrival,
                Plane = flight.Plane,
                PlaneCode = flight.PlaneCode,
                PilotName = flight.PilotName,
                FreeSeatsEconomy = flight.FreeSeatsEconomy,
                FreeSeatsBusiness = flight.FreeSeatsBusiness
            };

            return View(model);
        }

        // POST: Flights/Edit/5       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(FlightsEditViewModel editModel)
        {
            if (ModelState.IsValid)
            {
                Flight flight = new Flight()
                {
                    Id = editModel.Id,
                    From = editModel.From,
                    To = editModel.To,
                    Departure = editModel.Departure,
                    Arrival = editModel.Arrival,
                    Plane = editModel.Plane,
                    PlaneCode = editModel.PlaneCode,
                    PilotName = editModel.PilotName,
                    FreeSeatsEconomy = editModel.FreeSeatsEconomy,
                    FreeSeatsBusiness = editModel.FreeSeatsBusiness
                };

                try
                {
                    _context.Update(flight);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FlightExists(flight.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            return View(editModel);
        }


        // GET: Flights/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            Flight flight = await _context.Flights.FindAsync(id);
            _context.Flights.Remove(flight);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        private bool FlightExists(string id)
        {
            return _context.Flights.Any(e => e.Id == id);
        }
    }
}
