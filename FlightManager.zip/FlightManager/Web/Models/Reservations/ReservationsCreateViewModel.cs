﻿using System.ComponentModel.DataAnnotations;

namespace Web.Models.Reservations
{
    public class ReservationsCreateViewModel
    {
        [Required]
        public string FirstName { get; set; }

        [Required]
        public string SecondName { get; set; }

        [Required]
        public string LastName { get; set; }

        [Required]
        [StringLength(10, ErrorMessage = "EGN must be 10 characters long")]
        public string EGN { get; set; }

        public string PhoneNumber { get; set; }

        [Required]
        [EmailAddress(ErrorMessage = "E-mail is not valid")]
        public string Email { get; set; }

        [Required]
        public string Nationality { get; set; }

        [Required]
        public string FlightId { get; set; }

        [Required]
        public string ClassType { get; set; }

    }
}