﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Web.Models.Flights
{
    public class FlightsCreateViewModel
    {
        [Required]
        public string From { get; set; }

        [Required]
        public string To { get; set; }

        [Required]
        public DateTime Departure { get; set; }

        [Required]
        public DateTime Arrival { get; set; }

        [Required]
        [MaxLength(6, ErrorMessage = "Plane model cannot be longer than 6 characters")]
        public string Plane { get; set; }

        [Required]
        [MaxLength(6, ErrorMessage = "Plane code cannot be longer than 6 characters")]
        public string PlaneCode { get; set; }

        [Required]
        public string PilotName { get; set; }

        [Required]
        [Range(0, 500, ErrorMessage = "Negative values or values greater than 500 are not accepted")]
        public int FreeSeatsEconomy { get; set; }

        [Required]
        [Range(0, 500, ErrorMessage = "Negative values or values greater than 500 are not accepted")]
        public int FreeSeatsBusiness { get; set; }
    }
}
