﻿using System;

namespace Web.Models.Flights
{
    public class FlightsViewModel
    {
        public string Id { get; set; }

        public string From { get; set; }

        public string To { get; set; }

        public DateTime Departure { get; set; }

        public DateTime Arrival { get; set; }

        public string Plane { get; set; }

        public string PlaneCode { get; set; }

        public string PilotName { get; set; }

        public int FreeSeatsEconomy { get; set; }

        public int FreeSeatsBusiness { get; set; }
    }
}
