﻿namespace Data
{
    using Data.Entity;
    using Microsoft.AspNetCore.Identity;
    using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore;

    public class FlightsManagerDb : IdentityDbContext<User, IdentityRole, string>
    {
        public DbSet<Flight> Flights { get; set; }

        public DbSet<Reservation> Reservations { get; set; }


        public FlightsManagerDb(DbContextOptions<FlightsManagerDb> options) : base(options)
        {

        }

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlServer(@"Server=DESKTOP-0ACGJO1\SQLEXPRESS;Database=FlightManagerDatabase;Integrated Security=True");
        //    optionsBuilder.UseLazyLoadingProxies();
        //}
    }
}
