﻿using Microsoft.AspNetCore.Identity;

namespace Data.Entity
{
    public class User : IdentityUser<string>
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string EGN { get; set; }

        public string Address { get; set; }

    }
}
